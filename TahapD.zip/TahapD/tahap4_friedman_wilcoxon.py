#!/usr/bin/env python3
"""Tahap 4 - Pengujian Hipotesis Statistik Non-Parametrik (Friedman & Wilcoxon, alpha=0.05).

Input (otomatis terdeteksi dari Tahap3/):
  - hasil_svm_4fs_2cara.csv
  - fitur_lengkap_4fs_2cara.csv
Output:
  - laporan_lengkap_friedman_wilcoxon.csv   (delimiter ';')
  - ringkasan_uji_statistik_tahap4.png      (300 dpi, 2 panel)
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

if "get_ipython" not in globals():
    matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy import stats  # noqa: E402

BASE_DIR = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
OUT_REPORT_CSV = BASE_DIR / "laporan_lengkap_friedman_wilcoxon.csv"
OUT_SUMMARY_PNG = BASE_DIR / "ringkasan_uji_statistik_tahap4.png"

FS_LEVELS = ["orig", "48000", "22050", "16000"]
FS_TARGETS = ["48000", "22050", "16000"]
METHODS = ["with_aa", "no_aa"]
ALPHA = 0.05


def resolve_inputs() -> tuple[Path, Path]:
    dirs = [BASE_DIR, BASE_DIR / "Tahap3", BASE_DIR.parent / "Tahap3"]
    svm = next((d / "hasil_svm_4fs_2cara.csv" for d in dirs if (d / "hasil_svm_4fs_2cara.csv").is_file()), None)
    feat = next((d / "fitur_lengkap_4fs_2cara.csv" for d in dirs if (d / "fitur_lengkap_4fs_2cara.csv").is_file()), None)
    if not svm or not feat:
        raise FileNotFoundError(f"Input Tahap 3 tidak ditemukan pada {[str(d) for d in dirs]}")
    return svm, feat


def safe_wilcoxon(x: np.ndarray, y: np.ndarray, alt: str = "two-sided") -> tuple[float, float]:
    if np.allclose(x - y, 0.0):
        return 0.0, 1.0
    res = stats.wilcoxon(x, y, zero_method="wilcox", alternative=alt)
    return float(res.statistic), float(res.pvalue)


def fmt_p(p: float) -> str:
    return "-" if pd.isna(p) else (f"{p:.2e}" if p < 1e-4 else f"{p:.4f}")


def make_row(
    bagian: str, metode: str, metrik: str, hip: str, k1: str, k2: str,
    a: np.ndarray, b: np.ndarray, stat: float, p_two: float, p_one: float, status: str, note: str,
) -> dict:
    return {
        "bagian_uji": bagian, "metode_uji": metode, "metrik": metrik,
        "hipotesis_atau_pasangan": hip, "kondisi_1": k1, "kondisi_2": k2, "n_sampel": len(a),
        "mean_1": float(a.mean()), "median_1": float(np.median(a)),
        "mean_2": float(b.mean()), "median_2": float(np.median(b)),
        "selisih_mean": float(a.mean() - b.mean()), "statistik": stat,
        "p_value_two_sided": p_two, "p_value_one_sided": p_one, "alpha": ALPHA,
        "signifikan_two_sided": bool(p_two < ALPHA),
        "signifikan_one_sided": np.nan if pd.isna(p_one) else bool(p_one < ALPHA),
        "status_ringkas": status, "catatan_statistik": note,
    }


def run_friedman(df_svm: pd.DataFrame) -> tuple[list[dict], dict[str, dict[str, float]]]:
    print("\n[BAGIAN 1] UJI FRIEDMAN — Pengaruh Penurunan fs terhadap Macro F1 (5-Fold CV)")
    rows, summary = [], {}
    for cara in METHODS:
        piv = df_svm[df_svm["cara"] == cara].pivot(index="fold", columns="fs_label", values="macro_f1")[FS_LEVELS].sort_index()
        ranks = pd.Series(np.vstack([stats.rankdata(r) for r in piv.to_numpy(float)]).mean(axis=0), index=FS_LEVELS)
        chi2, p_f = map(float, stats.friedmanchisquare(*[piv[c].to_numpy() for c in FS_LEVELS]))
        kw = chi2 / (len(piv) * (len(FS_LEVELS) - 1))
        summary[cara] = {"chi2": chi2, "p_value": p_f, "kendall_w": kw}

        tbl = pd.DataFrame({
            "fs": FS_LEVELS, "mean_f1": piv.mean().values, "std_f1": piv.std(ddof=1).values,
            "mean_rank(4=max)": ranks.values,
        })
        print(f"\n>>> {cara}: chi2_F={chi2:.4f} | p={p_f:.4f} | Kendall's W={kw:.4f} | {'SIGNIFIKAN' if p_f < ALPHA else 'Tidak Signifikan'}")
        print(tbl.to_string(index=False, float_format=lambda v: f"{v:.4f}"))

        rank_str = ", ".join(f"{k}={ranks[k]:.2f}" for k in FS_LEVELS)
        rows.append(make_row(
            "Friedman (F1 antar 4 fs)", "Friedman chi-square", "macro_f1",
            f"H1: Minimal 1 tingkat fs berbeda ({cara})", f"orig ({cara})", f"48k / 22.05k / 16k ({cara})",
            piv["orig"].to_numpy(), piv["16000"].to_numpy(), chi2, p_f, np.nan,
            "Signifikan (p < 0.05)" if p_f < ALPHA else "Tidak Signifikan",
            f"Mean Rank (4=tertinggi): {rank_str} | Kendall's W={kw:.3f}",
        ))
    return rows, summary


def run_wilcoxon_f1(df_svm: pd.DataFrame) -> list[dict]:
    rows = []
    print("\n[BAGIAN 2A] UJI WILCOXON — Degradasi Macro F1 vs Baseline (orig)")
    for cara in METHODS:
        piv = df_svm[df_svm["cara"] == cara].pivot(index="fold", columns="fs_label", values="macro_f1").sort_index()
        s0 = piv["orig"].to_numpy(float)
        for ft in FS_TARGETS:
            sd = piv[ft].to_numpy(float)
            w, p2 = safe_wilcoxon(s0, sd, "two-sided")
            _, p1 = safe_wilcoxon(s0, sd, "greater")
            nd, n = int(np.sum(s0 > sd)), len(s0)
            if n == 5 and np.isclose(w, 0.0) and np.isclose(p2, 2.0 / 32.0):
                status = "Signifikan Searah (one-sided p=0.0313; batas two-sided N=5=0.0625)"
                note = f"Turun di {nd}/5 fold (W=0); p two-sided tertahan di batas 2/2^5=0.0625, signifikan searah (p={p1:.5f})."
            elif p2 < ALPHA:
                status, note = "Signifikan (two-sided p < 0.05)", f"Turun signifikan di {nd}/{n} fold."
            elif p1 < ALPHA:
                status, note = "Signifikan Searah (one-sided p < 0.05)", f"Turun konsisten di {nd}/{n} fold."
            else:
                status, note = "Tidak Signifikan", f"Turun di {nd}/{n} fold; belum signifikan pada alpha={ALPHA}."
            rows.append(make_row(
                "Wilcoxon Uji A (Degradasi F1 vs orig)", "Wilcoxon signed-rank", "macro_f1",
                f"orig vs {ft} Hz ({cara}) [H1: orig > {ft}]", f"orig_{cara}", f"{ft}_{cara}",
                s0, sd, w, p2, p1, status, note,
            ))

    print("\n[BAGIAN 2B] UJI WILCOXON — Perbandingan Metode pada F1 (with_aa vs no_aa)")
    for ft in FS_TARGETS:
        piv = df_svm[df_svm["fs_label"] == ft].pivot(index="fold", columns="cara", values="macro_f1").sort_index()
        a, b = piv["with_aa"].to_numpy(float), piv["no_aa"].to_numpy(float)
        w, p2 = safe_wilcoxon(a, b, "two-sided")
        status = "Signifikan (p < 0.05)" if p2 < ALPHA else "Tidak Signifikan"
        note = "Tidak berbeda signifikan pada F1 per-klip; verifikasi keutuhan sinyal fisik pada Uji C." if p2 >= ALPHA else "Berbeda signifikan pada alpha=0.05."
        rows.append(make_row(
            "Wilcoxon Uji B (F1 with_aa vs no_aa)", "Wilcoxon signed-rank", "macro_f1",
            f"with_aa vs no_aa @ {ft} Hz", f"{ft}_with_aa", f"{ft}_no_aa",
            a, b, w, p2, np.nan, status, note,
        ))
    return rows


def run_wilcoxon_spectral(df_feat: pd.DataFrame) -> tuple[list[dict], dict[str, pd.DataFrame], dict[str, float]]:
    print("\n[BAGIAN 2C] UJI WILCOXON — Lonjakan Error Spektral Pita 0-8 kHz (N=780 Klip)")
    rows, paired, pvals = [], {}, {}
    for ft in FS_TARGETS:
        piv = df_feat[df_feat["fs_label"] == ft].pivot(index="clip_id", columns="cara", values="low_band_error_pct").dropna().sort_index()
        paired[ft] = piv
        no, aa = piv["no_aa"].to_numpy(float), piv["with_aa"].to_numpy(float)
        w, p2 = safe_wilcoxon(no, aa, "two-sided")
        _, p1 = safe_wilcoxon(no, aa, "greater")
        pvals[ft] = p2
        pct = float(np.mean(no > aa) * 100.0)
        med_no, med_aa = float(np.median(no)), float(np.median(aa))
        status = "Sangat Signifikan (p < 0.001)" if p2 < 0.001 else ("Signifikan (p < 0.05)" if p2 < ALPHA else "Tidak Signifikan")
        note = f"{pct:.1f}% klip error no_aa > with_aa (median {med_no:.2f}% vs {med_aa:.2f}%, rasio ~{med_no / max(med_aa, 1e-12):.1f}x)."
        rows.append(make_row(
            "Wilcoxon Uji C (Error Spektral 0-8 kHz)", "Wilcoxon signed-rank", "low_band_error_pct",
            f"no_aa vs with_aa @ {ft} Hz [H1: no_aa > with_aa]", f"{ft}_no_aa", f"{ft}_with_aa",
            no, aa, w, p2, p1, status, note,
        ))
    return rows, paired, pvals


def styled_boxplot(ax, data, pos, edge: str, fill: str, whis=1.5):
    return ax.boxplot(
        data, positions=pos, widths=0.30, patch_artist=True, showfliers=False, whis=whis,
        boxprops={"facecolor": fill, "edgecolor": edge, "linewidth": 1.5},
        medianprops={"color": edge, "linewidth": 2.2},
        whiskerprops={"color": edge, "linewidth": 1.3},
        capprops={"color": edge, "linewidth": 1.3},
    )


def plot_summary(df_svm: pd.DataFrame, f_sum: dict, paired: dict[str, pd.DataFrame], p_spec: dict[str, float]) -> None:
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14.0, 5.8), dpi=300)
    c_aa, f_aa, c_no, f_no, off = "#1B4F72", "#AED6F1", "#B03A2E", "#F5B7B1", 0.18

    # Panel A: Boxplot F1 + Friedman
    x1 = np.arange(len(FS_LEVELS), dtype=float)
    d_aa = [df_svm[(df_svm["cara"] == "with_aa") & (df_svm["fs_label"] == l)]["macro_f1"].to_numpy() for l in FS_LEVELS]
    d_no = [df_svm[(df_svm["cara"] == "no_aa") & (df_svm["fs_label"] == l)]["macro_f1"].to_numpy() for l in FS_LEVELS]
    bp_aa = styled_boxplot(ax1, d_aa, x1 - off, c_aa, f_aa)
    bp_no = styled_boxplot(ax1, d_no, x1 + off, c_no, f_no)

    rng = np.random.default_rng(42)
    for i in range(len(FS_LEVELS)):
        ax1.scatter(np.full(len(d_aa[i]), x1[i] - off) + rng.uniform(-0.04, 0.04, len(d_aa[i])), d_aa[i], color=c_aa, s=26, alpha=0.85, zorder=5)
        ax1.scatter(np.full(len(d_no[i]), x1[i] + off) + rng.uniform(-0.04, 0.04, len(d_no[i])), d_no[i], color=c_no, marker="s", s=24, alpha=0.85, zorder=5)

    fa, fn = f_sum["with_aa"], f_sum["no_aa"]
    ax1.text(
        0.03, 0.04,
        f"Uji Friedman (Antar 4 tingkat fs, N=5 fold):\n"
        f"• with_aa: $\\chi^2_F$ = {fa['chi2']:.2f}, p = {fa['p_value']:.4f} (Signifikan)\n"
        f"• no_aa  : $\\chi^2_F$ = {fn['chi2']:.2f}, p = {fn['p_value']:.4f} (Signifikan)",
        transform=ax1.transAxes, fontsize=8.4, va="bottom",
        bbox={"boxstyle": "round,pad=0.45", "facecolor": "#F8F9F9", "edgecolor": "#7F8C8D", "alpha": 0.95},
    )
    ax1.set_xticks(x1)
    ax1.set_xticklabels(["Asli\n(>=96 kHz)", "48 kHz", "22,05 kHz", "16 kHz"], fontsize=9.5)
    ax1.set_ylim(0.71, 1.02)
    ax1.set(xlabel="Tingkat Frekuensi Sampling (fs)", ylabel="Macro F1-Score (5-Fold CV)")
    ax1.set_title("A. Distribusi Macro F1-Score & Uji Friedman", fontsize=11.2, fontweight="bold", pad=10)
    ax1.grid(True, axis="y", linestyle=":", alpha=0.55)
    ax1.spines[["top", "right"]].set_visible(False)
    ax1.legend([bp_aa["boxes"][0], bp_no["boxes"][0]], ["Dengan Anti-Aliasing (with_aa)", "Tanpa Anti-Aliasing (no_aa)"], loc="upper right", fontsize=8.5)

    # Panel B: Spectral Error Log + Wilcoxon
    x2, eps = np.arange(len(FS_TARGETS), dtype=float), 1e-2
    e_aa = [np.maximum(paired[t]["with_aa"].to_numpy(), eps) for t in FS_TARGETS]
    e_no = [np.maximum(paired[t]["no_aa"].to_numpy(), eps) for t in FS_TARGETS]
    b2_aa = styled_boxplot(ax2, e_aa, x2 - off, c_aa, f_aa, whis=(5, 95))
    b2_no = styled_boxplot(ax2, e_no, x2 + off, c_no, f_no, whis=(5, 95))
    ax2.set_yscale("log")

    y_tops = []
    for i, t in enumerate(FS_TARGETS):
        yb = max(float(np.percentile(e_aa[i], 95)), float(np.percentile(e_no[i], 95))) * 1.85
        y_tops.append(yb * 2.5)
        xa, xb = x2[i] - off, x2[i] + off
        ax2.plot([xa, xa, xb, xb], [yb * 0.78, yb, yb, yb * 0.78], color="#2C3E50", lw=1.2)
        pv = p_spec[t]
        stars = "***" if pv < 0.001 else ("**" if pv < 0.01 else ("*" if pv < 0.05 else "ns"))
        ax2.text(x2[i], yb * 1.18, f"Wilcoxon {stars}\np = {fmt_p(pv)}", ha="center", va="bottom", fontsize=7.9, fontweight="bold", color="#2C3E50")
        ax2.text(xa, float(np.percentile(e_aa[i], 5)) * 0.62, f"Med:\n{np.median(paired[t]['with_aa']):.2f}%", ha="center", va="top", fontsize=7.5, color=c_aa, fontweight="bold")
        ax2.text(xb, float(np.percentile(e_no[i], 5)) * 0.62, f"Med:\n{np.median(paired[t]['no_aa']):.1f}%", ha="center", va="top", fontsize=7.5, color=c_no, fontweight="bold")

    ax2.set_ylim(1.2e-3, max(y_tops) * 4.5)
    ax2.set_xticks(x2)
    ax2.set_xticklabels(["48 kHz", "22,05 kHz", "16 kHz"], fontsize=9.5)
    ax2.set(xlabel="Tingkat Frekuensi Sampling Target (fs)", ylabel="Error Spektral Pita Rendah 0–8 kHz (%, Skala Log)")
    ax2.set_title("B. Distorsi Aliasing Pita 0–8 kHz (N=780 Klip) & Uji Wilcoxon", fontsize=11.2, fontweight="bold", pad=10)
    ax2.grid(True, axis="y", which="both", linestyle=":", alpha=0.5)
    ax2.spines[["top", "right"]].set_visible(False)
    ax2.legend([b2_aa["boxes"][0], b2_no["boxes"][0]], ["Dengan Anti-Aliasing (with_aa)", "Tanpa Anti-Aliasing (no_aa / Aliasing)"], loc="upper left", fontsize=8.5)

    fig.suptitle("Tahap 4 — Ringkasan Pengujian Hipotesis Statistik Non-Parametrik (α = 0,05)", fontsize=13, fontweight="bold", y=0.99)
    fig.tight_layout(rect=[0.0, 0.0, 1.0, 0.95])
    fig.savefig(OUT_SUMMARY_PNG, dpi=300)
    plt.show() if "get_ipython" in globals() else plt.close(fig)
    print(f"Grafik tersimpan (300 dpi): {OUT_SUMMARY_PNG}")


def main() -> None:
    svm_csv, feat_csv = resolve_inputs()
    df_svm = pd.read_csv(svm_csv, sep=";", dtype={"fs_label": str, "cara": str})
    df_feat = pd.read_csv(feat_csv, sep=";", dtype={"fs_label": str, "cara": str, "clip_id": str})

    r_friedman, f_sum = run_friedman(df_svm)
    r_f1 = run_wilcoxon_f1(df_svm)
    r_spec, paired, p_spec = run_wilcoxon_spectral(df_feat)

    df_rep = pd.DataFrame(r_friedman + r_f1 + r_spec)
    df_rep.to_csv(OUT_REPORT_CSV, sep=";", index=False, float_format="%.6g")

    print("\n=== RINGKASAN LENGKAP UJI FRIEDMAN & WILCOXON (TAHAP 4) ===")
    cols = ["bagian_uji", "hipotesis_atau_pasangan", "n_sampel", "statistik", "p_value_two_sided", "p_value_one_sided", "status_ringkas"]
    disp = df_rep[cols].copy()
    disp["p_value_two_sided"] = disp["p_value_two_sided"].map(fmt_p)
    disp["p_value_one_sided"] = disp["p_value_one_sided"].map(fmt_p)
    print(disp.to_string(index=False))

    plot_summary(df_svm, f_sum, paired, p_spec)
    print(f"Laporan CSV tersimpan: {OUT_REPORT_CSV}")


if __name__ == "__main__":
    main()
