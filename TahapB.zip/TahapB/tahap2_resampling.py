#!/usr/bin/env python3
"""Tahap 2 - Eksperimen resampling: 4 tingkat fs x 2 cara (with_aa / no_aa).

Input  : ../Tahap1/subset_5_spesies_fs_min96k.csv  (delimiter ';')
         ../Tahap1/subset_orthoptera_wav/           (audio asli, fs >= 96 kHz)
Output : dataset_resampled/{orig, 48000_with_aa, 48000_no_aa, 22050_with_aa, ...}/
         log_tahap2_resampling.csv   (delimiter ';')
         verifikasi_aliasing_contoh.png

Cara 1 (with_aa) : LPF Butterworth orde-8 fasa-nol (sosfiltfilt) di fc = 0,9 * fs_target/2
                   pada fs asli, lalu resample_poly (up/down = fs_target/gcd : fs_orig/gcd,
                   FIR polifase Kaiser bawaan SciPy).
Cara 2 (no_aa)   : direct subsampling tanpa filter: y[round(k * fs_orig / fs_target)].
"""
import math
import shutil
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import soundfile as sf  # noqa: E402
from scipy import signal  # noqa: E402

BASE = Path(__file__).resolve().parent
TAHAP1 = BASE.parent / "Tahap1"
IN_CSV = TAHAP1 / "subset_5_spesies_fs_min96k.csv"
IN_DIR = TAHAP1 / "subset_orthoptera_wav"
OUT_ROOT = BASE / "dataset_resampled"
LOG_CSV = BASE / "log_tahap2_resampling.csv"
FIG_PNG = BASE / "verifikasi_aliasing_contoh.png"

TARGET_FS = [48_000, 22_050, 16_000]
FS_MIN = 96_000
BUTTER_ORDER = 8
CUTOFF_FRAC = 0.9          # fc = 0,9 * (fs_target / 2)
SUBTYPE_OUT = "FLOAT"      # WAV float32: tidak ada clipping, amplitudo (dan energi) apa adanya
PLOT_SPECIES = "Tettigonia_viridissima"
PLOT_MAX_SEC = 5.0


# ----------------------------------------------------------------------------- DSP
def resample_with_aa(y: np.ndarray, fs_orig: int, fs_target: int) -> np.ndarray:
    """LPF anti-aliasing eksplisit (Butterworth orde-8, fasa-nol) + resample_poly rasional."""
    fc = CUTOFF_FRAC * fs_target / 2.0
    sos = signal.butter(BUTTER_ORDER, fc, btype="low", fs=fs_orig, output="sos")
    y_lp = signal.sosfiltfilt(sos, y)
    g = math.gcd(fs_orig, fs_target)
    up, down = fs_target // g, fs_orig // g
    return signal.resample_poly(y_lp, up, down)


def resample_no_aa(y: np.ndarray, fs_orig: int, fs_target: int) -> np.ndarray:
    """Naive decimation: ambil sampel pada indeks waktu eksak tanpa filter (aliasing alami)."""
    idx = np.round(np.arange(0, len(y), fs_orig / fs_target)).astype(np.int64)
    idx = idx[idx <= len(y) - 1]
    return y[idx]


# ----------------------------------------------------------------------------- metrik
def energy(x: np.ndarray, fs: int) -> float:
    """Energi total (Parseval, domain waktu): sum |x[n]|^2 / fs."""
    return float(np.sum(np.square(x, dtype=np.float64)) / fs)


def metrics(x: np.ndarray, fs: int) -> dict:
    return {
        "n": int(len(x)),
        "dur": len(x) / fs,
        "energy": energy(x, fs),
        "peak": float(np.max(np.abs(x))) if len(x) else 0.0,
    }


def save_wav(path: Path, x: np.ndarray, fs: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(path), x.astype(np.float32), fs, subtype=SUBTYPE_OUT)


def cond_dir(fs_target: int, method: str) -> Path:
    return OUT_ROOT / f"{fs_target}_{method}"


# ----------------------------------------------------------------------------- proses
def process_file(row, log_rows: list, errors: list) -> None:
    name, species, fs_csv = row.file_name, row.species_name, int(row.fs_hz)
    src = IN_DIR / name
    try:
        info = sf.info(str(src))
        if info.samplerate != fs_csv:
            raise ValueError(f"fs CSV {fs_csv} != fs header {info.samplerate}")
        y, fs_orig = sf.read(str(src), dtype="float64", always_2d=False)
        if y.ndim > 1:
            y = y.mean(axis=1)
        if fs_orig < FS_MIN:
            raise ValueError(f"fs {fs_orig} < {FS_MIN}")
    except Exception as e:  # noqa: BLE001
        errors.append((name, f"baca: {e}"))
        return

    # baseline: salin file asli apa adanya (fs & kuantisasi tidak diubah)
    p_orig = OUT_ROOT / "orig" / name
    try:
        p_orig.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, p_orig)
    except Exception as e:  # noqa: BLE001
        errors.append((name, f"salin orig: {e}"))
        return
    m0 = metrics(y, fs_orig)

    for fs_t in TARGET_FS:
        rec = {
            "file_name": name, "species_name": species,
            "fs_orig": fs_orig, "fs_target": fs_t,
            "path_orig": str(p_orig.relative_to(BASE)),
            "n_orig": m0["n"], "dur_orig_s": round(m0["dur"], 6),
            "energy_orig": m0["energy"], "peak_orig": m0["peak"],
            "butter_order": BUTTER_ORDER, "cutoff_hz": CUTOFF_FRAC * fs_t / 2,
            "up": fs_t // math.gcd(fs_orig, fs_t), "down": fs_orig // math.gcd(fs_orig, fs_t),
            "status": "ok",
        }
        try:
            for tag, fn in (("with_aa", resample_with_aa), ("no_aa", resample_no_aa)):
                x = fn(y, fs_orig, fs_t)
                p = cond_dir(fs_t, tag) / name
                save_wav(p, x, fs_t)
                m = metrics(x, fs_t)
                rec.update({
                    f"path_{tag}": str(p.relative_to(BASE)),
                    f"n_{tag}": m["n"],
                    f"dur_{tag}_s": round(m["dur"], 6),
                    f"dur_err_{tag}_s": round(m["dur"] - m0["dur"], 6),
                    f"energy_{tag}": m["energy"],
                    f"energy_ratio_{tag}": m["energy"] / m0["energy"] if m0["energy"] > 0 else np.nan,
                    f"peak_{tag}": m["peak"],
                    f"clip_{tag}": bool(m["peak"] > 1.0),
                })
                rec[f"energy_loss_{tag}"] = 1.0 - rec[f"energy_ratio_{tag}"]
        except Exception as e:  # noqa: BLE001
            rec["status"] = f"gagal: {e}"
            errors.append((name, f"fs {fs_t}: {e}"))
        log_rows.append(rec)


# ----------------------------------------------------------------------------- plot
def make_figure(df_in: pd.DataFrame, log: pd.DataFrame) -> None:
    cand = df_in[df_in["species_name"] == PLOT_SPECIES]
    cand = cand[cand["duration_sec"] >= 3].sort_values(["fs_hz", "duration_sec"], ascending=[False, True])
    ok_names = set(log.loc[log["status"] == "ok", "file_name"])
    cand = cand[cand["file_name"].isin(ok_names)]
    if cand.empty:
        print(f"[!] tidak ada contoh {PLOT_SPECIES} untuk gambar")
        return
    name = cand.iloc[0]["file_name"]
    fs_t = 16_000
    paths = {
        f"Asli ({int(cand.iloc[0]['fs_hz']) // 1000} kHz)": OUT_ROOT / "orig" / name,
        f"{fs_t // 1000} kHz with_aa": cond_dir(fs_t, "with_aa") / name,
        f"{fs_t // 1000} kHz no_aa (aliasing)": cond_dir(fs_t, "no_aa") / name,
    }
    sigs = {}
    for lbl, p in paths.items():
        x, fs = sf.read(str(p), dtype="float64", frames=-1)
        x = x[: int(PLOT_MAX_SEC * fs)]
        sigs[lbl] = (x, fs)

    fig = plt.figure(figsize=(16, 10), constrained_layout=True)
    gs = fig.add_gridspec(2, 3)
    ax_full, ax_zoom = fig.add_subplot(gs[0, :2]), fig.add_subplot(gs[0, 2])
    colors = ["tab:gray", "tab:blue", "tab:red"]
    for (lbl, (x, fs)), c in zip(sigs.items(), colors):
        f, pxx = signal.welch(x, fs=fs, nperseg=min(8192, len(x)))
        db = 10 * np.log10(pxx + 1e-20)
        ax_full.plot(f / 1e3, db, color=c, lw=0.9, label=lbl)
        m = f <= fs_t / 2
        ax_zoom.plot(f[m] / 1e3, db[m], color=c, lw=0.9, label=lbl)
    ax_full.axvline(fs_t / 2e3, color="k", ls="--", lw=0.8, label=f"Nyquist {fs_t // 2000} kHz")
    ax_zoom.axvline(fs_t / 2e3, color="k", ls="--", lw=0.8)
    ax_full.set(title=f"PSD Welch - {name}", xlabel="Frekuensi (kHz)", ylabel="PSD (dB/Hz)")
    ax_zoom.set(title="Zoom 0 - 8 kHz (pita hasil resampling)", xlabel="Frekuensi (kHz)")
    ax_full.legend()
    ax_zoom.legend(fontsize=8)
    ax_full.grid(alpha=0.3)
    ax_zoom.grid(alpha=0.3)

    for i, (lbl, (x, fs)) in enumerate(sigs.items()):
        ax = fig.add_subplot(gs[1, i])
        f, t, sxx = signal.spectrogram(x, fs=fs, nperseg=1024, noverlap=512)
        ax.pcolormesh(t, f / 1e3, 10 * np.log10(sxx + 1e-20), shading="auto", cmap="magma")
        ax.set(title=f"Spektrogram - {lbl}", xlabel="Waktu (s)", ylabel="Frekuensi (kHz)")
    fig.suptitle("Verifikasi aliasing: spektrum ultrasonik terlipat ke pita rendah pada no_aa", fontsize=14)
    fig.savefig(FIG_PNG, dpi=130)
    plt.close(fig)
    print(f"Gambar verifikasi: {FIG_PNG.name} (sumber: {name})")


# ----------------------------------------------------------------------------- main
def main() -> None:
    df = pd.read_csv(IN_CSV, sep=";")
    need = {"file_name", "species_name", "fs_hz", "channels", "duration_sec"}
    if not need.issubset(df.columns):
        raise SystemExit(f"Kolom CSV kurang: {need - set(df.columns)}")
    OUT_ROOT.mkdir(parents=True, exist_ok=True)

    log_rows, errors = [], []
    t0 = time.time()
    n = len(df)
    for i, row in enumerate(df.itertuples(index=False), 1):
        process_file(row, log_rows, errors)
        print(f"[{i:2d}/{n}] {row.file_name}  ({time.time() - t0:.0f}s)", flush=True)

    log = pd.DataFrame(log_rows)
    log.to_csv(LOG_CSV, index=False, sep=";")
    print(f"\nLog: {LOG_CSV.name} ({len(log)} baris)")

    ok = log[log["status"] == "ok"]
    if not ok.empty:
        summ = ok.groupby("fs_target").agg(
            n_file=("file_name", "size"),
            rasio_E_with_aa=("energy_ratio_with_aa", "mean"),
            rugi_E_with_aa=("energy_loss_with_aa", "mean"),
            rasio_E_no_aa=("energy_ratio_no_aa", "mean"),
            rugi_E_no_aa=("energy_loss_no_aa", "mean"),
            clip_with_aa=("clip_with_aa", "sum"),
            clip_no_aa=("clip_no_aa", "sum"),
        ).sort_index(ascending=False)
        print("\n=== Rata-rata perubahan energi per fs target (rasio = E_hasil / E_orig) ===")
        print(summ.to_string(float_format=lambda v: f"{v:.4f}"))
        make_figure(df, log)

    print(f"\nSelesai: {ok['file_name'].nunique() if not ok.empty else 0}/{n} file, "
          f"{len(errors)} error, {time.time() - t0:.0f}s")
    for name, why in errors:
        print(f"  GAGAL {name}: {why}")


if __name__ == "__main__":
    main()
