#!/usr/bin/env python3
"""Tahap 3 - Pipeline Ringkas: Resampling 4 fs x 2 cara + Fitur + SVM 5-Fold + Statistik.

Menjawab: "Berapa frekuensi sampling (fs) minimum agar ciri suara belalang tetap utuh?"
untuk menyimpan klip ke dataset_resampled/ (PCM_16) atau --reuse-wav jika sudah ada.
"""

from __future__ import annotations

import argparse
import math
import time
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import soundfile as sf  # noqa: E402
from scipy import fft as sp_fft, signal, stats  # noqa: E402
from sklearn.metrics import f1_score  # noqa: E402
from sklearn.model_selection import StratifiedKFold  # noqa: E402
from sklearn.pipeline import Pipeline  # noqa: E402
from sklearn.preprocessing import StandardScaler  # noqa: E402
from sklearn.svm import SVC  # noqa: E402

BASE_DIR = Path(__file__).resolve().parent
OUT_AUDIO_ROOT = BASE_DIR / "dataset_resampled"
OUT_FEATURES_CSV = BASE_DIR / "fitur_lengkap_4fs_2cara.csv"
OUT_ENERGY_CSV = BASE_DIR / "tabel_energi_hilang_vs_fs.csv"
OUT_SVM_CSV = BASE_DIR / "hasil_svm_4fs_2cara.csv"
OUT_STATS_CSV = BASE_DIR / "hasil_uji_statistik_friedman_wilcoxon.csv"
OUT_PLOT_PNG = BASE_DIR / "kurva_f1_vs_fs.png"

FS_MIN, CLIP_SEC, MAX_CLIPS = 96_000, 2.0, 15
FS_TARGETS = [48_000, 22_050, 16_000]
FS_LEVELS = ["orig", "48000", "22050", "16000"]
METHODS = ["with_aa", "no_aa"]
BUTTER_ORDER, CUTOFF_FRAC = 8, 0.9
WELCH_WIN_SEC, LOW_GRID = 0.020, np.linspace(0.0, 8_000.0, 161)
ENV_FS, ENV_LPF_ORDER, ENV_LPF_HZ, CHIRP_MIN, CHIRP_MAX = 1_000, 4, 50.0, 1.0, 40.0
N_FOLDS, SEED, ALPHA = 5, 42, 0.05

BANDS = (
    ("0_4k", 0.0, 4_000.0, True),
    ("4_8k", 4_000.0, 8_000.0, False),
    ("8_11k", 8_000.0, 11_025.0, False),
    ("11_24k", 11_025.0, 24_000.0, False),
    ("gt24k", 24_000.0, np.inf, False),
)
SVM_FEATURES = [
    "total_energy",
    *[f"energy_abs_{k}" for k, *_ in BANDS],
    *[f"energy_rel_{k}" for k, *_ in BANDS],
    "spectral_centroid_hz", "spectral_bandwidth_hz", "chirp_rate_hz", "autocorr_peak",
]


def resolve_inputs() -> tuple[Path, Path]:
    dirs = [BASE_DIR, BASE_DIR / "Tahap1", BASE_DIR.parent / "Tahap1"]
    csv_p = next((d / "subset_5_spesies_fs_min96k.csv" for d in dirs if (d / "subset_5_spesies_fs_min96k.csv").is_file()), None)
    wav_d = next((d / "subset_orthoptera_wav" for d in dirs if (d / "subset_orthoptera_wav").is_dir()), None)
    if not csv_p or not wav_d:
        raise FileNotFoundError(f"Input Tahap 1 tidak ditemukan pada {[str(d) for d in dirs]}")
    return csv_p, wav_d


def clip_starts(n_total: int, fs: int) -> list[int]:
    n_clip = int(round(CLIP_SEC * fs))
    if n_total < n_clip:
        return [0]
    k = min(MAX_CLIPS, n_total // n_clip)
    return [(n_total - n_clip) // 2] if k == 1 else np.round(np.linspace(0, n_total - n_clip, k)).astype(np.int64).tolist()


def segment_clips(y: np.ndarray, fs: int) -> list[tuple[int, float, np.ndarray]]:
    n_clip = int(round(CLIP_SEC * fs))
    starts = clip_starts(len(y), fs)
    segs = [np.pad(y, (0, n_clip - len(y)))] if len(y) < n_clip else [y[s : s + n_clip] for s in starts]
    out = []
    for idx, (s, seg) in enumerate(zip(starts, segs)):
        seg = np.asarray(seg, dtype=np.float64)
        peak = float(np.max(np.abs(seg)))
        out.append((idx, s / fs, seg / peak if peak > 0 else seg))
    return out


def resample_with_aa(y: np.ndarray, fs_orig: int, fs_target: int) -> np.ndarray:
    sos = signal.butter(BUTTER_ORDER, CUTOFF_FRAC * fs_target / 2.0, btype="low", fs=fs_orig, output="sos")
    g = math.gcd(fs_orig, fs_target)
    return signal.resample_poly(signal.sosfiltfilt(sos, y), fs_target // g, fs_orig // g).astype(np.float64, copy=False)


def resample_no_aa(y: np.ndarray, fs_orig: int, fs_target: int) -> np.ndarray:
    idx = np.round(np.arange(0, len(y), fs_orig / fs_target)).astype(np.int64)
    return y[idx[idx < len(y)]].astype(np.float64, copy=False)


def extract_chirp_rate(x: np.ndarray, fs: int) -> tuple[float, float]:
    n = len(x)
    if n < 16 or float(np.max(np.abs(x))) <= 1e-12:
        return 0.0, 0.0
    env = np.abs(signal.hilbert(x, N=sp_fft.next_fast_len(n))[:n])
    g = math.gcd(fs, ENV_FS)
    env_ds = signal.resample_poly(env, ENV_FS // g, fs // g)
    sos = signal.butter(ENV_LPF_ORDER, ENV_LPF_HZ, btype="low", fs=ENV_FS, output="sos")
    e = signal.sosfiltfilt(sos, env_ds)
    e = e - float(np.mean(e))
    denom = float(np.dot(e, e))
    if denom <= 1e-18:
        return 0.0, 0.0
    acf = signal.correlate(e, e, mode="full", method="fft")[len(e) - 1 :] / denom
    lo, hi = max(1, int(round(ENV_FS / CHIRP_MAX))), min(int(round(ENV_FS / CHIRP_MIN)), len(acf) - 1)
    if hi <= lo:
        return 0.0, 0.0
    win = acf[lo : hi + 1]
    peaks, _ = signal.find_peaks(win)
    best = lo + (int(peaks[int(np.argmax(win[peaks]))]) if len(peaks) else int(np.argmax(win)))
    return float(ENV_FS / best), float(acf[best])


def extract_record(
    x: np.ndarray, fs: int, fs_label: str, cara: str, meta: dict,
    e_orig: float | None = None, psd_orig_low: np.ndarray | None = None,
) -> tuple[dict, np.ndarray]:
    total_e = float(np.sum(np.square(x, dtype=np.float64)) / fs)
    nperseg = min(len(x), max(64, int(round(WELCH_WIN_SEC * fs))))
    f, pxx = signal.welch(x, fs=fs, window="hann", nperseg=nperseg, noverlap=nperseg // 2, scaling="density", detrend=False)
    pxx = np.maximum(pxx, 0.0)
    scale = (float(f[1] - f[0]) if len(f) > 1 else 1.0) * (len(x) / float(fs))
    psd_tot = float(np.sum(pxx) * scale)

    feats: dict[str, float] = {"total_energy": total_e}
    for key, lo, hi, inc_lo in BANDS:
        mask = (f >= lo) & (f <= hi) if inc_lo else (f > lo) & (f <= hi)
        e_abs = float(np.sum(pxx[mask]) * scale) if np.any(mask) else 0.0
        feats[f"energy_abs_{key}"] = e_abs
        feats[f"energy_rel_{key}"] = e_abs / psd_tot if psd_tot > 1e-18 else 0.0

    pxx_sum = float(np.sum(pxx))
    centroid = float(np.sum(f * pxx) / pxx_sum) if pxx_sum > 1e-18 else 0.0
    bandwidth = float(np.sqrt(np.sum(((f - centroid) ** 2) * pxx) / pxx_sum)) if pxx_sum > 1e-18 else 0.0
    psd_low = np.interp(LOW_GRID, f, pxx, left=0.0, right=0.0)
    chirp_hz, acf_peak = extract_chirp_rate(x, fs)

    e_loss = ((e_orig - total_e) / e_orig * 100.0) if (e_orig and e_orig > 1e-18) else 0.0
    low_denom = float(np.sum(psd_orig_low)) if psd_orig_low is not None else 0.0
    low_err = float(np.sum(np.abs(psd_low - psd_orig_low)) / low_denom * 100.0) if low_denom > 1e-18 else 0.0

    return {
        **meta, "fs_label": fs_label, "fs_actual_hz": int(fs), "cara": cara, **feats,
        "spectral_centroid_hz": centroid, "spectral_bandwidth_hz": bandwidth,
        "chirp_rate_hz": chirp_hz, "autocorr_peak": acf_peak,
        "energy_loss_pct": float(e_loss), "low_band_error_pct": float(low_err),
    }, psd_low


def run_feature_pipeline(df_meta: pd.DataFrame, wav_dir: Path, save_wav: bool, reuse_wav: bool) -> pd.DataFrame:
    if save_wav:
        OUT_AUDIO_ROOT.mkdir(parents=True, exist_ok=True)
    records, t0 = [], time.time()
    mode = "reuse WAV" if reuse_wav else ("resample + simpan PCM_16" if save_wav else "in-memory (hemat storage)")
    print(f"\n[TAHAP 1-3] Segmentasi + Resampling (4 fs x 2 cara) + Ekstraksi Fitur [{mode}]")

    resamplers = (("with_aa", resample_with_aa), ("no_aa", resample_no_aa))
    for idx, row in enumerate(df_meta.itertuples(index=False), start=1):
        fname, sp, fs_csv = str(row.file_name).strip(), str(row.species_name).strip(), int(row.fs_hz)
        src = wav_dir / fname
        info = sf.info(str(src))
        fs_orig = int(info.samplerate)
        if fs_orig != fs_csv or fs_orig < FS_MIN:
            raise ValueError(f"{fname}: fs={fs_orig} tidak valid (CSV={fs_csv})")

        stem = Path(fname).stem
        starts = clip_starts(info.frames, fs_orig)
        can_reuse = reuse_wav and all(
            (OUT_AUDIO_ROOT / d / f"{stem}_clip{k:02d}.wav").is_file()
            for k in range(len(starts))
            for d in ["orig", *(f"{ft}_{m}" for ft in FS_TARGETS for m in METHODS)]
        )
        if can_reuse:
            clip_iter = [(k, s / fs_orig, None) for k, s in enumerate(starts)]
        else:
            y, _ = sf.read(str(src), dtype="float64", always_2d=False)
            clip_iter = segment_clips(np.mean(y, axis=1) if y.ndim > 1 else y, fs_orig)

        for c_idx, start_s, c_orig in clip_iter:
            cid = f"{stem}_clip{c_idx:02d}"
            p_orig = OUT_AUDIO_ROOT / "orig" / f"{cid}.wav"
            if c_orig is None:
                c_orig, _ = sf.read(str(p_orig), dtype="float64", always_2d=False)
            elif save_wav:
                p_orig.parent.mkdir(parents=True, exist_ok=True)
                sf.write(str(p_orig), np.clip(c_orig, -1.0, 1.0), fs_orig, subtype="PCM_16")

            meta = {"clip_id": cid, "file_name": fname, "species_name": sp,
                    "clip_index": c_idx, "clip_start_sec": round(start_s, 4), "fs_orig_hz": fs_orig}
            rec0, psd0 = extract_record(c_orig, fs_orig, "orig", "with_aa", meta)
            e0 = float(rec0["total_energy"])
            records.extend((rec0, {**rec0, "cara": "no_aa"}))

            for fs_t in FS_TARGETS:
                for cara, fn in resamplers:
                    p_out = OUT_AUDIO_ROOT / f"{fs_t}_{cara}" / f"{cid}.wav"
                    if can_reuse:
                        x, _ = sf.read(str(p_out), dtype="float64", always_2d=False)
                    else:
                        x = fn(c_orig, fs_orig, fs_t)
                        if save_wav:
                            p_out.parent.mkdir(parents=True, exist_ok=True)
                            sf.write(str(p_out), np.clip(x, -1.0, 1.0), fs_t, subtype="PCM_16")
                    rec, _ = extract_record(x, fs_t, str(fs_t), cara, meta, e0, psd0)
                    records.append(rec)

        print(f"  [{idx:02d}/{len(df_meta)}] {fname:<46s} | fs={fs_orig//1000:3d} kHz | klip={len(starts):2d} | {time.time()-t0:5.1f}s", flush=True)

    df_feat = pd.DataFrame(records)
    df_feat.to_csv(OUT_FEATURES_CSV, sep=";", index=False, float_format="%.6g")

    orig_df = df_feat[(df_feat["fs_label"] == "orig") & (df_feat["cara"] == "with_aa")]
    print("\n--- Distribusi Klip Seragam (2.0 detik) per Spesies ---")
    print(orig_df.groupby("species_name").agg(n_file=("file_name", "nunique"), n_klip=("clip_id", "size")).to_string())

    df_energy = (
        df_feat.groupby(["fs_label", "cara"], as_index=False)
        .agg(
            n_klip=("clip_id", "size"),
            mean_total_energy=("total_energy", "mean"),
            mean_energy_loss_pct=("energy_loss_pct", "mean"),
            std_energy_loss_pct=("energy_loss_pct", "std"),
            mean_low_band_error_pct=("low_band_error_pct", "mean"),
            std_low_band_error_pct=("low_band_error_pct", "std"),
            **{f"mean_rel_{k}": (f"energy_rel_{k}", "mean") for k, *_ in BANDS},
            mean_centroid_hz=("spectral_centroid_hz", "mean"),
            mean_bandwidth_hz=("spectral_bandwidth_hz", "mean"),
            mean_chirp_rate_hz=("chirp_rate_hz", "mean"),
            mean_autocorr_peak=("autocorr_peak", "mean"),
        )
    )
    df_energy = (
        df_energy.assign(_f=df_energy["fs_label"].map({v: i for i, v in enumerate(FS_LEVELS)}),
                         _c=df_energy["cara"].map({v: i for i, v in enumerate(METHODS)}))
        .sort_values(["_f", "_c"]).drop(columns=["_f", "_c"]).reset_index(drop=True)
    )
    df_energy.to_csv(OUT_ENERGY_CSV, sep=";", index=False, float_format="%.6g")
    print("\n--- Ringkasan Energi Hilang & Error Spektral (0-8 kHz) vs fs ---")
    cols = ["fs_label", "cara", "mean_energy_loss_pct", "mean_low_band_error_pct", "mean_rel_gt24k", "mean_centroid_hz", "mean_chirp_rate_hz"]
    print(df_energy[cols].to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    return df_feat


def run_svm_cv(df_feat: pd.DataFrame) -> dict[tuple[str, str], np.ndarray]:
    print("\n[TAHAP 4] Klasifikasi SVM (RBF, C=10.0) 5-Fold Stratified CV pada 8 Skenario")
    skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    rows, score_map = [], {}

    for fs_lbl in FS_LEVELS:
        for cara in METHODS:
            sub = df_feat[(df_feat["fs_label"] == fs_lbl) & (df_feat["cara"] == cara)].sort_values("clip_id")
            X, y = sub[SVM_FEATURES].to_numpy(dtype=np.float64), sub["species_name"].to_numpy()
            scores = np.array([
                float(f1_score(y[te], Pipeline([
                    ("scaler", StandardScaler()),
                    ("svm", SVC(kernel="rbf", C=10.0, gamma="scale", random_state=SEED)),
                ]).fit(X[tr], y[tr]).predict(X[te]), average="macro"))
                for tr, te in skf.split(X, y)
            ])
            score_map[(fs_lbl, cara)] = scores
            mean_f1, std_f1 = float(scores.mean()), float(scores.std(ddof=1))
            rows.extend({
                "fs_label": fs_lbl, "cara": cara, "fold": f_i, "macro_f1": float(val),
                "mean_macro_f1": mean_f1, "std_macro_f1": std_f1, "n_samples": len(sub),
            } for f_i, val in enumerate(scores, start=1))

    df_svm = pd.DataFrame(rows)
    df_svm.to_csv(OUT_SVM_CSV, sep=";", index=False, float_format="%.6g")
    summary = df_svm.groupby(["fs_label", "cara"], sort=False, as_index=False).agg(
        mean_macro_f1=("macro_f1", "mean"),
        std_macro_f1=("macro_f1", lambda s: float(np.std(s, ddof=1))),
        min_f1=("macro_f1", "min"), max_f1=("macro_f1", "max"),
    )
    print(summary.to_string(index=False, float_format=lambda v: f"{v:.4f}"))
    return score_map


def run_stats_and_plot(score_map: dict[tuple[str, str], np.ndarray]) -> None:
    print(f"\n[TAHAP 5] Uji Friedman & Wilcoxon (alpha = {ALPHA}) + Kurva F1 vs fs")
    rows, fpvals = [], {}

    def add_row(uji: str, kat: str, k1: str, k2: str, s1: np.ndarray, s2: np.ndarray, stat: float, p: float) -> None:
        sig = bool(p < ALPHA)
        rows.append({
            "uji": uji, "kategori": kat, "kondisi_1": k1, "kondisi_2": k2, "n_fold": N_FOLDS,
            "mean_1": float(s1.mean()), "mean_2": float(s2.mean()), "selisih_mean": float(s1.mean() - s2.mean()),
            "statistik": stat, "p_value": p, "alpha": ALPHA, "signifikan": sig,
            "status_signifikansi": "Signifikan (p < 0.05)" if sig else "Tidak Signifikan",
        })

    for cara in METHODS:
        s_all = [score_map[(lvl, cara)] for lvl in FS_LEVELS]
        stat_f, p_f = map(float, stats.friedmanchisquare(*s_all))
        fpvals[cara] = p_f
        add_row("Friedman", f"Antar 4 tingkat fs ({cara})", f"orig_{cara}", f"48k_22k_16k_{cara}", s_all[0], s_all[-1], stat_f, p_f)

    pairs = [
        *((f"with_aa vs no_aa @ {ft} Hz", f"{ft}_with_aa", f"{ft}_no_aa", score_map[(str(ft), "with_aa")], score_map[(str(ft), "no_aa")]) for ft in FS_TARGETS),
        *((f"orig vs {ft} Hz ({c})", f"orig_{c}", f"{ft}_{c}", score_map[("orig", c)], score_map[(str(ft), c)]) for c in METHODS for ft in FS_TARGETS),
    ]
    for kat, k1, k2, a, b in pairs:
        if np.allclose(a - b, 0.0):
            stat_w, p_w = 0.0, 1.0
        else:
            res = stats.wilcoxon(a, b, zero_method="wilcox", alternative="two-sided")
            stat_w, p_w = float(res.statistic), float(res.pvalue)
        add_row("Wilcoxon", kat, k1, k2, a, b, stat_w, p_w)

    df_stats = pd.DataFrame(rows)
    df_stats.to_csv(OUT_STATS_CSV, sep=";", index=False, float_format="%.6g")
    print(df_stats[["uji", "kategori", "mean_1", "mean_2", "selisih_mean", "statistik", "p_value", "status_signifikansi"]].to_string(index=False, float_format=lambda v: f"{v:.4f}"))

    # Plot Kurva Macro F1-Score vs fs (300 dpi)
    x = np.arange(len(FS_LEVELS), dtype=float)
    m_aa = np.array([score_map[(l, "with_aa")].mean() for l in FS_LEVELS])
    s_aa = np.array([score_map[(l, "with_aa")].std(ddof=1) for l in FS_LEVELS])
    m_no = np.array([score_map[(l, "no_aa")].mean() for l in FS_LEVELS])
    s_no = np.array([score_map[(l, "no_aa")].std(ddof=1) for l in FS_LEVELS])

    fig, ax = plt.subplots(figsize=(9.5, 5.8), dpi=300)
    dx = 0.035
    ax.errorbar(x - dx, m_aa, yerr=s_aa, fmt="-o", color="#1B4F72", ecolor="#2E86C1", lw=2.4, elinewidth=1.8, capsize=5, ms=8,
                label=f"Dengan Filter Anti-Aliasing (with_aa)  [Friedman p={fpvals['with_aa']:.4f}]", zorder=4)
    ax.errorbar(x + dx, m_no, yerr=s_no, fmt="--s", color="#B03A2E", ecolor="#E74C3C", lw=2.4, elinewidth=1.8, capsize=5, ms=8,
                label=f"Tanpa Filter Anti-Aliasing (no_aa / Naive)  [Friedman p={fpvals['no_aa']:.4f}]", zorder=3)

    for i in range(len(FS_LEVELS)):
        if i == 0:
            ax.annotate(f"{m_aa[0]:.3f} ± {s_aa[0]:.3f}", (0, m_aa[0] + s_aa[0]), textcoords="offset points", xytext=(0, 8), ha="center", fontsize=8.5, fontweight="bold", color="#2C3E50")
        else:
            up = m_aa[i] >= m_no[i]
            ax.annotate(f"{m_aa[i]:.3f}±{s_aa[i]:.3f}", (x[i] - dx, m_aa[i] + (s_aa[i] if up else -s_aa[i])),
                        textcoords="offset points", xytext=(-6, 9 if up else -16), ha="center", fontsize=8.3, fontweight="bold", color="#1B4F72")
            ax.annotate(f"{m_no[i]:.3f}±{s_no[i]:.3f}", (x[i] + dx, m_no[i] + (-s_no[i] if up else s_no[i])),
                        textcoords="offset points", xytext=(6, -16 if up else 9), ha="center", fontsize=8.3, fontweight="bold", color="#B03A2E")

    ax.set_ylim(max(0.0, min((m_aa - s_aa).min(), (m_no - s_no).min()) - 0.08), min(1.03, max((m_aa + s_aa).max(), (m_no + s_no).max()) + 0.08))
    ax.set_xlim(-0.35, len(FS_LEVELS) - 0.65)
    ax.set_xticks(x)
    ax.set_xticklabels(["Asli (orig)\n>= 96 kHz", "48 kHz\n(Nyquist 24 kHz)", "22,05 kHz\n(Nyquist 11,025 kHz)", "16 kHz\n(Nyquist 8 kHz)"], fontsize=9.5)
    ax.set(xlabel="Tingkat Frekuensi Sampling (fs)", ylabel="Macro F1-Score (5-Fold Stratified CV)")
    ax.set_title("Pengaruh Frekuensi Sampling & Filter Anti-Aliasing\nterhadap Klasifikasi SVM 5 Spesies Orthoptera", fontsize=12, fontweight="bold", pad=10)
    ax.grid(True, linestyle=":", alpha=0.55)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(loc="lower left", frameon=True, framealpha=0.95, fontsize=9.2)
    fig.tight_layout()
    fig.savefig(OUT_PLOT_PNG, dpi=300)
    plt.close(fig)
    print(f"Grafik tersimpan (300 dpi): {OUT_PLOT_PNG.name}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Pipeline 4 fs x 2 cara + Fitur + SVM + Statistik")
    parser.add_argument("--save-wav", action="store_true", help="Simpan WAV resampled (PCM_16) ke dataset_resampled/.")
    parser.add_argument("--reuse-wav", action="store_true", help="Pakai ulang WAV yang sudah ada di dataset_resampled/.")
    args = parser.parse_args()

    t0 = time.time()
    in_csv, in_wav = resolve_inputs()
    df_meta = pd.read_csv(in_csv, sep=";")
    df_feat = run_feature_pipeline(df_meta, in_wav, save_wav=args.save_wav, reuse_wav=args.reuse_wav)
    score_map = run_svm_cv(df_feat)
    run_stats_and_plot(score_map)
    print(f"\nSelesai dalam {time.time() - t0:.1f}s -> {BASE_DIR}")


if __name__ == "__main__":
    main()
