#!/usr/bin/env python3
"""Tahap 1 - InsectSet459: seleksi 5 spesies Orthoptera, ekstraksi subset, audit fs.
"""
import shutil
from pathlib import Path

import pandas as pd
import soundfile as sf

BASE = Path(__file__).resolve().parent
ANNOT_CSV = BASE / "InsectSet459_Train_Val_Test_Annotation.csv"
VAL_DIR = BASE.parent / "Validation"  # folder audio Validation (sudah diekstrak)
OUT_DIR = BASE / "subset_orthoptera_wav"
SUBSET_CSV = BASE / "subset_5_spesies_orthoptera_val.csv"
LOG_CSV = BASE / "log_fs_semua_subset.csv"
FINAL_CSV = BASE / "subset_5_spesies_fs_min96k.csv"
N_SPECIES = 5
FS_MIN = 96_000


def select_species(csv_path: Path):
    df = pd.read_csv(csv_path, sep=";", dtype=str)
    df["file_name"] = df["file_name"].str.strip()
    mask = (
        (df["group"] == "Orthoptera")
        & (df["subset"] == "Validation")
        & df["file_name"].str.lower().str.endswith(".wav")
    )
    wav = df[mask].copy()
    wav["is_xc"] = wav["file_name"].str.contains("_XC")
    summary = (
        wav.groupby("species_name")
        .agg(n_wav=("file_name", "size"), n_xc=("is_xc", "sum"))
        .reset_index()
        # prioritas: jumlah .wav terbanyak, lalu jumlah rekaman XC terbanyak
        .sort_values(["n_wav", "n_xc", "species_name"], ascending=[False, False, True])
        .head(N_SPECIES)
        .reset_index(drop=True)
    )
    subset = wav[wav["species_name"].isin(summary["species_name"])].copy()
    return summary, subset.drop(columns="is_xc").reset_index(drop=True)


def copy_files(names, src_dir: Path, out_dir: Path):
    """Salin file audio dari folder Validation ke out_dir. Return (ok, gagal)."""
    out_dir.mkdir(exist_ok=True)
    ok, failed = [], []
    for name in names:
        try:
            dst = out_dir / name
            src = src_dir / name
            if src.exists():
                shutil.copy2(src, dst)
            elif not dst.exists():  # tidak ada di Validation dan belum pernah disalin
                raise FileNotFoundError(f"tidak ada di {src_dir}")
            ok.append(name)
        except Exception as e:  # noqa: BLE001
            failed.append((name, f"salin: {e}"))
    return ok, failed


def audit_fs(names, out_dir: Path):
    rows, failed = [], []
    for name in names:
        try:
            info = sf.info(str(out_dir / name))  # hanya header
            rows.append({
                "file_name": name,
                "fs_hz": info.samplerate,
                "fs_khz": info.samplerate / 1000,
                "channels": info.channels,
                "duration_sec": round(info.frames / info.samplerate, 3),
            })
        except Exception as e:  # noqa: BLE001
            failed.append((name, f"header: {e}"))
    cols = ["file_name", "fs_hz", "fs_khz", "channels", "duration_sec"]
    return pd.DataFrame(rows, columns=cols), failed


def main():
    summary, subset = select_species(ANNOT_CSV)
    print("=== 5 spesies terpilih ===")
    print(summary.to_string(index=False))
    subset.to_csv(SUBSET_CSV, index=False, sep=";")

    ok, fail1 = copy_files(subset["file_name"].tolist(), VAL_DIR, OUT_DIR)
    fs_df, fail2 = audit_fs(ok, OUT_DIR)

    log = subset.merge(fs_df, on="file_name", how="left")
    log.to_csv(LOG_CSV, index=False, sep=";")

    final = log[log["fs_hz"] >= FS_MIN]
    final.to_csv(FINAL_CSV, index=False, sep=";")

    print("\n=== Distribusi fs (semua subset) ===")
    print(log["fs_hz"].value_counts(dropna=False).sort_index().to_string())
    print(f"\n=== File valid fs >= {FS_MIN} Hz per spesies ===")
    print(final["species_name"].value_counts().reindex(summary["species_name"], fill_value=0).to_string())
    print("\n=== Ringkasan ===")
    print(f"Total subset: {len(subset)} | terekstrak: {len(ok)} | "
          f"terbaca header: {len(fs_df)} | lolos >= 96 kHz: {len(final)}")
    for name, why in fail1 + fail2:
        print(f"  GAGAL {name}: {why}")


if __name__ == "__main__":
    main()
